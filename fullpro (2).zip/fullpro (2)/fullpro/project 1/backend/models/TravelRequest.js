const mongoose = require('mongoose');

const travelRequestSchema = new mongoose.Schema({
  employee: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  destination: { type: String, required: true },
  purpose: { type: String, required: true },
  start: { type: Date, required: true },
  end: { type: Date, required: true },
  status: { type: String, enum: ['Pending', 'Approved', 'Rejected'], default: 'Pending' },
  itinerary: { type: String }, // file URL or path
  comments: [{ body: String, date: Date, by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' } }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('TravelRequest', travelRequestSchema);
